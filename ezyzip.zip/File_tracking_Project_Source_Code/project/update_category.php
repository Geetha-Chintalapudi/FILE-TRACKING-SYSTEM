<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/functions.php');

if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

if(isset($_GET['upid']))
{
	$id1=$_GET['upid'];
}

$sql = "SELECT * from categories where id='$id1'";
$cnt=1;
$run_sql = 	mysqli_query($con,$sql);

$row = mysqli_fetch_array($run_sql);

$title = stripslashes($row['cat_name']);


if(isset($_POST['update']))
{
$title =addslashes( $_POST['title']);

$is_home = (isset($_POST['display'])) ? "Yes" :"No";

	  $update_sql="update categories set cat_name='$title',is_cat_home='$is_home' where id='$id1'";
             
			 if (mysqli_query($con, $update_sql)) {
		        //  echo "Updated: ";
			 header('location:manage_category.php');
				} 
				else {
				echo "Error: " . $sql . "<br>" . mysqli_error($con);
				}
         //print_r($errors);
      



			 
		


}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>HIRA SCHOOL | Update Activity</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
	
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Update Category Settings</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Update Category Info
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">


<div class="form-group">
	<label> Title<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="title" autocomplete="off"  value="<?php echo $title; ?>" required />
</div>

<div class="form-group">

	<label> Display In Page<span style="color:red;">*</span></label><br>

	<?php  if($row['is_cat_home']=="Yes") {?>

	<input type="checkbox" name="display" value="Yes" checked> Display In Page<br>

	<?php } else

	{
		?>
		<input type="checkbox" name="display" value="No" > Display In HomePage<br>
	<?php } ?>

</div>

 
<button type="submit" name="update" class="btn btn-info">Update </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="<?php echo $site_url; ?>assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo $site_url; ?>assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="<?php echo $site_url; ?>assets/js/custom.js"></script>
	<script>
		
	</script>
</body>
</html>
<?php } ?>
