<?php 
include('includes/config.php');
include('includes/functions.php');
if(!empty($_POST["categories"])) 
{
	 $categories=$_POST["categories"];
	 $cat_id=explode("-",$categories);
	 
	 
	
	$subsql = "SELECT * from subcategories where cat_id='$cat_id[0]' ";
				$run_subsql = 	mysqli_query($con,$subsql);
				      
	              
				 
				   
	
  
	
?>
<div class="form-group" id="sub_div">

	<label>Subcategories <span style="color:red;">*</span></label><br>
	 <input list="subcategory" class="form-control" name="sub_category" placeholder="Select Subcategory">
		<datalist id="subcategory" >
		<?php while($srow = mysqli_fetch_array($run_subsql))	{   ?>
			<option value="<?php  echo $srow['id']."-".$srow['sub_cat_name']; ?>"></option>
		<?php } ?>		                                   
 
            </datalist>
</div>
<?php } ?>

