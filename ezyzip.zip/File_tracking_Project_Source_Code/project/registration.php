<?php
session_start();
include('includes/config.php');

if(isset($_GET['emsg']))
{
	$id = $_GET['emsg'];
	$id = $_SESSION['error']="Error Occured";
}



if (isset($_POST['update'])) 
{
	$username=addslashes($_POST['uname']);
	$email=addslashes($_POST['uemail']);
	$password=md5($_POST['upassword']);
	$dept_code=addslashes($_POST['udepart_code']);
	 $position=addslashes($_POST['upostion']);

	$collegename=addslashes($_POST['collegename']);
	$collegecode=addslashes($_POST['collegecode']);
	$user_id="Fs-".rand(0,99999);
    $dept_name=$_POST['dept_name'];

	$fetchusers="select * from users where email='$email'";
    $runfetch=mysqli_query($con,$fetchusers);
    $fetcount=mysqli_num_rows($runfetch);


    if ($fetcount>0) {
    	
    echo "<script>alert('Email Already Exist ');</script>";
       
  

 } else {


       $insert_user="insert into users (
               user_name , user_id , email , u_password , dept_code ,posistion, collegename ,collegecode,register_date,dept_name)
     values ('$username' , '$user_id' , '$email' , '$password' , '$dept_code' , '$position' , '$collegename' , '$collegecode',now(),'$dept_name')";



     if ($run_insert=mysqli_query($con,$insert_user)) {
         $last_id = mysqli_insert_id($con);
         $select_sql="select * from users where id='$last_id'";
         $run_select=mysqli_query($con,$select_sql);
         $mysql_fetch=mysqli_fetch_array($run_select);
         $date_time=$mysql_fetch['register_date'];


         $userid=$last_id."-".$dept_code."-".$collegecode."-".$date_time;

         $update_user="update users set user_id=' $userid' where id='$last_id'";
         $run_update=mysqli_query($con,$update_user);
         if ($run_update) {
              header('location:dashboard.php');
         }

        
   

     }else
     {
     	 header('location:registration.php?emsg=msg');
         $_SESSION['error']="Error Occured";
     	
     
     }
  }
}

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>File Sharing  | Registration</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">New Registration</h4>
                            </div>
</div>

<?php // if($_SESSION['success']!="")
//{?>
<!-- <div class="col-md-6">
<div class="alert alert-success" >
 <strong>Success :</strong> 
 <?php //echo htmlentities($_SESSION['success']);?>
<?php //echo htmlentities($_SESSION['success']="");?>
</div>
</div> -->
<?php // } ?>
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Enter Details
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">
<div class="form-group">
	<label>Username<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="uname" autocomplete="off"  required />
</div>
<div class="form-group">
	<label>Email<span style="color:red;">*</span></label>
	<input class="form-control" type="email" name="uemail" autocomplete="off"   required />
</div>
<div class="form-group">
	<label>Password<span style="color:red;">*</span></label>
	<input class="form-control" type="Password" name="upassword" autocomplete="off"   required />
</div>
<div class="form-group">
    <label>Department Name<span style="color:red;">*</span></label>
    <input class="form-control" type="text" name="dept_name" autocomplete="off"   required />
</div>

<div class="form-group">
	<label>Department Code<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="udepart_code" autocomplete="off"   required />
</div>
<div class="form-group">
	<label>Position<span style="color:red;">*</span></label><br>
	<select class="form-control" name="upostion" >
		<option value="Hod">HOD</option>
		<option value="Principal">Principal</option>
	</select>
	
</div>
<div class="form-group">
	<label>College Name<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="collegename" autocomplete="off" required />
</div>
<div class="form-group">
	<label>College Code<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="collegecode" autocomplete="off"   required />
</div>


 

<button type="submit" name="update" class="btn btn-info">Submit</button>
                </form>
    </div>
</div>
    </div>
        </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php  ?>
