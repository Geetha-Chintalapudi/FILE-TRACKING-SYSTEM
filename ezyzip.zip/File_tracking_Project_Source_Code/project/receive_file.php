<?php
session_start();

error_reporting(0);
include('includes/config.php');
include('includes/functions.php');


if(strlen($_SESSION['alogin'])==0 && strlen($_SESSION['ulogin'])==0)
{   
header('location:index.php');
}
else{ 

 if(isset($_SESSION['ulogin']))
 {
  $receiver_email = $_SESSION['ulogin'];
  $get_userid = "select * from users where email = '$receiver_email'";
  $run_userid = mysqli_query($con, $get_userid);
  $row_userid = mysqli_fetch_array($run_userid);
   $receiver_id = $row_userid['id'];
 } 

 //update received files notification
$update_noti = "update send_files set noti = '1' where receiver = '$receiver_id'";
$run_update_noti = mysqli_query($con, $update_noti);


if(isset($_GET['upid']))
{
  $file_id = $_GET['upid'];
   $remarks = $_GET['remarks'];

  $sql = "update send_files set status = 'accept' where id = '$file_id'";
  if (mysqli_query($con, $sql)) 
  {
    
   $_SESSION['success'] = "Request Accepted";

   $sql1 = "SELECT * from send_files where id = '$file_id' ";

  $run_sql1 =  mysqli_query($con,$sql1);

  $row_file = mysqli_fetch_array($run_sql1);

  $receiver_email1 = explode("@", $receiver_email);

  $name = $receiver_email1[0];

  $target_file = "files/".$name."/";

  $file_name1 = explode("/", $row_file[file]);
    $file_name2 = $file_name1[2];
    $copy_path = $target_file.$file_name2;

  if(!is_dir($target_file))
  {
    mkdir("files/".$name."/",0777,true);
     if(copy($row_file[file], $copy_path))
      {
        header("Location:".$site_url."receive_file.php");
      }
    
  }else
  {
    if(copy($row_file[file], $copy_path))
      {
        header("Location:".$site_url."receive_file.php");
      }
  }
 
        
  }   
  else {
    
   $_SESSION['error']="Request Not Accepted";
    }
  
}

if(isset($_GET['del']))
{
  $file_id = $_GET['del'];

  $sql = "update send_files set status = 'reject' where id = '$file_id'";
  if (mysqli_query($con, $sql)) 
  {
    
   $_SESSION['success'] = "Request Rejected";
   
    header("Location:".$site_url."receive_file.php");
      
  }   
  else {
    
   $_SESSION['error']="Request Not Rejected";
    }
  
}

if(isset($_GET['file']))
{
  header("Content-Type: application/octet-stream");

  $file = "files/".$_GET["file"];
  header("Content-Disposition: attachment; filename=" . urlencode($file));   
  header("Content-Type: application/octet-stream");
  header("Content-Type: application/download");
  header("Content-Description: File Transfer");            
  header("Content-Length: " . filesize($file));
  flush(); // this doesn't really matter.
  $fp = fopen($file, "r");
  while (!feof($fp))
  {
      echo fread($fp, 65536);
      flush(); // this is essential for large downloads
  } 
  fclose($fp);
  }
  if(isset($_POST['send_remarks']))
  {
    $file_id = $_POST['file_id'];
    $remarks = $_POST['remarks'];

    $sql = "update send_files set remarks = '$remarks' where id = '$file_id'";
  if (mysqli_query($con, $sql)) 
  {
    
   $_SESSION['success'] = "Remarks Sent";
   
  header("Location:".$site_url."receive_file.php");      
  }   
  else {
    
   $_SESSION['error']="Remarks Not Sent";
    }

  }
			
?>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <meta name="description" content="" />

    <meta name="author" content="" />

    <title>File Sharing| Received Files</title>

    <!-- BOOTSTRAP CORE STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/bootstrap.css" rel="stylesheet" />

    <!-- FONT AWESOME STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/font-awesome.css" rel="stylesheet" />

    <!-- DATATABLE STYLE  -->

    <link href="<?php echo $site_url; ?>assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

    <!-- CUSTOM STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/style.css" rel="stylesheet" />

    <!-- GOOGLE FONT -->

    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



</head>

<body>

      <!------MENU SECTION START-->

<?php include('includes/header.php');?>

<!-- MENU SECTION END-->

        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">

         <div class="">

        <div class="row">

            <div class="col-md-12">

                <h4 class="header-line">Received Files</h4>

    </div>

     <div class="row">

    <?php if($_SESSION['error']!="")

    {?>

<div class="col-md-6">

<div class="alert alert-danger" >

 <strong>Error :</strong> 

 <?php echo htmlentities($_SESSION['error']);?>

<?php echo htmlentities($_SESSION['error']="");?>

</div>

</div>

<?php } ?>

<?php if($_SESSION['msg']!="")

{?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['msg']);?>

<?php echo htmlentities($_SESSION['msg']="");?>

</div>

</div>

<?php } ?>

<?php if($_SESSION['updatemsg']!="")

{?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['updatemsg']);?>

<?php echo htmlentities($_SESSION['updatemsg']="");?>

</div>

</div>

<?php } ?>





   <?php if($_SESSION['delmsg']!="")

    {?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['delmsg']);?>

<?php echo htmlentities($_SESSION['delmsg']="");?>

</div>

</div>

<?php } ?>



</div>

        </div>

            <div class="row">

                <div class="col-md-12">

                    <!-- Advanced Tables -->

                    <div class="panel panel-default">

                        <div class="panel-heading">

                           Received Files

                        </div>

                        <div class="panel-body">

                            <div class="table-responsive">

                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">

                                    <thead>

                                        <tr>

                                            <th>Sender id</th>

                                            <th>Sender Name</th>

                                            <th>File</th>

                                            <th>File Subject</th>

                                            <th>upload Date</th>
                                            <th>Expiry Date</th>
                                            <th>No. of days Remaining for the file to expire</th>

                                            <th>Remarks</th>

                                            <th>Action</th>

                                        </tr>

                                    </thead>

                                    <tbody>



<?php $sql = "SELECT * from send_files where receiver = '$receiver_id' ";

  $run_sql =  mysqli_query($con,$sql);

  $cnt = 1;

  while($row = mysqli_fetch_array($run_sql))

{
    $sender_id = $row['sender'];
    $get_sender_name = "select * from users where id = '$sender_id'";
    $run_sender_name = mysqli_query($con, $get_sender_name);
    $row_sender_name = mysqli_fetch_array($run_sender_name);
    $sender_name = $row_sender_name['user_name'];
    $file1 = explode("/", $row['file']);
    $file_name = $file1[2];
    $sender_user_id = $row_sender_name['user_id'];
   ?>                                      

                                        <tr class="odd gradeX">

                                            <td class="center"><?php echo $sender_user_id; ?></td>
                      
                                            <td class="center"><?php echo $sender_name; ?></td>

                                            <td class="center"><?php echo htmlentities(stripslashes($file_name));?></td>

                                             <td class="center"><?php echo $row['subject']; ?></td>

                                              <td class="center"><?php echo htmlentities(stripslashes($row['upload_date']));?></td> <td class="center"><?php echo htmlentities(stripslashes($row['expiry_date']));?></td>
                                              <td class="center">
                                                <?php           
                                                      $date1=date_create($row['upload_date']);
                                                      $date2=date_create($row['expiry_date']);
                                                      $diff=date_diff($date1,$date2);
                                                      $differ= $diff->format("%R%a days");
                                                      $range=explode(" ", $differ);
                                                      $splitday=explode("+", $range[0]);
                                                      if($splitday[1] == 1)
                                                      {
                                                         echo $splitday[1]." Day";
                                                      }else if($splitday[1] > 1)
                                                      {
                                                         echo $splitday[1]." Days";
                                                      }
                                                      if($splitday[1] < 1)
                                                      {
                                                         echo "File Expired";
                                                      }
                                                     
                                                 ?> </td>
                              
                                            <td class="center">
                                              <form method="post" action="">
                                              <textarea id="remark<?php echo $cnt; ?>" placeholder="Enter Remarks" name="remarks" rows="5" cols="15" ><?php echo $row['remarks']; ?></textarea><br><br>
                                              <input type="hidden" name="file_id" value="<?php echo $row['id']; ?>">
                                              <input type="submit" name="send_remarks" value="Send" class="btn btn-primary">
                                            </form>
                                            </td>
                                            <?php
                                              if($row['status']=="no")
                                              {
                                            ?>
                                            <td class="center">

                                            <a href="receive_file.php?upid=<?php echo htmlentities($row['id']);?>"><button class="btn btn-primary">Accept</button> </a>

                                          <a href="receive_file.php?del=<?php echo htmlentities($row['id']);?>" id="reject" onclick="reject('remark<?php echo $cnt; ?>');">  <button class="btn btn-danger">Reject</button></a>
                                      

                      </td>
                    <?php } else if($row['status']=="accept") { 
                      // $date1=date_create("2020-03-15");
                      // $date2=date_create("2020-03-14");

                          $date1=date_create($row['upload_date']);
                          $date2=date_create($row['expiry_date']);
                          $diff=date_diff($date1,$date2);
                          $differ= $diff->format("%R%a days");
                          $range=explode(" ", $differ);
                           $range[0];
                          if ($range[0] < 0) {   ?>
                                          

                                          <td class="center">  
                                            <a class="btn btn-danger" >Link Expired </a>
                                            
                                          </td>
                                        <?php } else { ?> 

                                           <td class="center">  
                                            <a href="receive_file.php?file=<?php echo htmlentities($row['file']);?>"><button class="btn btn-primary">Download</button>
                                            </a><br>
                                            <a href="forward.php?forwardfile=<?php echo htmlentities($file_name);?>"><button class="btn btn-primary">Forward file</button></a>
                                            
                                          </td>

                                        <?php } } else if($row['status']=="reject") { ?>
                                          <td class="center">

                                            <a><button class="btn btn-danger" disabled="">Rejected</button>
                                            </a>
                                          </td>
                                        <?php } ?>

                                        </tr>

<?php $cnt++;}?>                                      

                                    </tbody>

                                </table>

                            </div>

                            

                        </div>

                    </div>

                    <!--End Advanced Tables -->

                </div>

            </div>            

    </div>

    </div>



     <!-- CONTENT-WRAPPER SECTION END-->

  <?php include('includes/footer.php');?>

      <!-- FOOTER SECTION END-->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->

    <!-- CORE JQUERY  -->

    <script src="<?php echo $site_url; ?>assets/js/jquery-1.10.2.js"></script>

    <!-- BOOTSTRAP SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/bootstrap.js"></script>

    <!-- DATATABLE SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/dataTables/jquery.dataTables.js"></script>

    <script src="<?php echo $site_url; ?>assets/js/dataTables/dataTables.bootstrap.js"></script>

      <!-- CUSTOM SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/custom.js"></script>

    <script type="text/javascript">
  //     $('#reject').click(function(){
  //       var a = document.getElementById("remark");
  //       if(a.value == "")
  //       {
  //         alert("Please Send your Remarks and then reject the file")
  //         event.preventDefault();
  //       }
  // });

  function reject(remark)
  {
        var a = document.getElementById(remark);
        if(a.value == "")
        {
          alert("Please Send your Remarks and then reject the file")
          event.preventDefault();
        }
  }
    </script>

</body>

</html>

<?php

 } 

?>
