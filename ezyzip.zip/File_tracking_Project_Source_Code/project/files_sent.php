<?php
session_start();

error_reporting(0);
include('includes/config.php');
include('includes/functions.php');


if(strlen($_SESSION['alogin'])==0 && strlen($_SESSION['ulogin'])==0)
{   
header('location:index.php');
}
else{ 

 if(isset($_SESSION['ulogin']))
 {
  $receiver_email = $_SESSION['ulogin'];
  $get_userid = "select * from users where email = '$receiver_email'";
  $run_userid = mysqli_query($con, $get_userid);
  $row_userid = mysqli_fetch_array($run_userid);
   $receiver_id = $row_userid['id'];
 } 

if(isset($_GET['upid']))
{
  $file_id = $_GET['upid'];
   $remarks = $_GET['remarks'];

  $sql = "update send_files set status = 'accept' where id = '$file_id'";
  if (mysqli_query($con, $sql)) 
  {
    
   $_SESSION['success'] = "Request Accepted";
   
  header("Location:".$site_url."receive_file.php");      
  }   
  else {
    
   $_SESSION['error']="Request Not Accepted";
    }
  
}

if(isset($_GET['del']))
{
  $file_id = $_GET['del'];

  $sql = "update send_files set status = 'reject' where id = '$file_id'";
  if (mysqli_query($con, $sql)) 
  {
    
   $_SESSION['success'] = "Request Rejected";
   
    header("Location:".$site_url."receive_file.php");
      
  }   
  else {
    
   $_SESSION['error']="Request Not Rejected";
    }
  
}

if(isset($_GET['file']))
{
  header("Content-Type: application/octet-stream");

  $file = "files/".$_GET["file"];
  header("Content-Disposition: attachment; filename=" . urlencode($file));   
  header("Content-Type: application/octet-stream");
  header("Content-Type: application/download");
  header("Content-Description: File Transfer");            
  header("Content-Length: " . filesize($file));
  flush(); // this doesn't really matter.
  $fp = fopen($file, "r");
  while (!feof($fp))
  {
      echo fread($fp, 65536);
      flush(); // this is essential for large downloads
  } 
  fclose($fp);
  }
  // if(isset($_POST['send_remarks']))
  // {
  //   $file_id = $_POST['file_id'];
  //   $remarks = $_POST['remarks'];

  //   $sql = "update send_files set remarks = '$remarks' where id = '$file_id'";
  // if (mysqli_query($con, $sql)) 
  // {
    
  //  $_SESSION['success'] = "Remarks Sent";
   
  // header("Location:".$site_url."receive_file.php");      
  // }   
  // else {
    
  //  $_SESSION['error']="Remarks Not Sent";
  //   }

  // }
			
?>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <meta name="description" content="" />

    <meta name="author" content="" />

    <title>File Sharing| Received Files</title>

    <!-- BOOTSTRAP CORE STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/bootstrap.css" rel="stylesheet" />

    <!-- FONT AWESOME STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/font-awesome.css" rel="stylesheet" />

    <!-- DATATABLE STYLE  -->

    <link href="<?php echo $site_url; ?>assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

    <!-- CUSTOM STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/style.css" rel="stylesheet" />

    <!-- GOOGLE FONT -->

    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



</head>

<body>

      <!------MENU SECTION START-->

<?php include('includes/header.php');?>

<!-- MENU SECTION END-->

        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">

         <div class="">

        <div class="row">

            <div class="col-md-12">

                <h4 class="header-line">Sent Files</h4>

    </div>

     <div class="row">

    <?php if($_SESSION['error']!="")

    {?>

<div class="col-md-6">

<div class="alert alert-danger" >

 <strong>Error :</strong> 

 <?php echo htmlentities($_SESSION['error']);?>

<?php echo htmlentities($_SESSION['error']="");?>

</div>

</div>

<?php } ?>

<?php if($_SESSION['msg']!="")

{?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['msg']);?>

<?php echo htmlentities($_SESSION['msg']="");?>

</div>

</div>

<?php } ?>

<?php if($_SESSION['updatemsg']!="")

{?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['updatemsg']);?>

<?php echo htmlentities($_SESSION['updatemsg']="");?>

</div>

</div>

<?php } ?>





   <?php if($_SESSION['delmsg']!="")

    {?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['delmsg']);?>

<?php echo htmlentities($_SESSION['delmsg']="");?>

</div>

</div>

<?php } ?>



</div>

        </div>

            <div class="row">

                <div class="col-md-12">

                    <!-- Advanced Tables -->

                    <div class="panel panel-default">

                        <div class="panel-heading">

                           Sent Files

                        </div>

                        <div class="panel-body">

                            <div class="table-responsive">

                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">

                                    <thead>

                                        <tr>

                                            <th>Reciever id</th>

                                            <th>Reciever Name</th>

                                            <th>File</th>

                                            <th>File Subject</th>

                                            <th>upload Date</th>
                                            <th>Expiry Date</th>

                                            <th>Remarks</th>

                                            <th>Action</th>

                                        </tr>

                                    </thead>

                                    <tbody>



<?php

  $sql = "SELECT * from send_files where sender = '$receiver_id' ";

  $run_sql =  mysqli_query($con,$sql);

  $cnt = 1;


  while($row = mysqli_fetch_array($run_sql))

{
    $sender_id = $row['receiver'];
    $get_sender_name = "select * from users where id = '$sender_id'";
    $run_sender_name = mysqli_query($con, $get_sender_name);
    $row_sender_name = mysqli_fetch_array($run_sender_name);
    $sender_name = $row_sender_name['user_name'];
    $sent_file=$row['file'];
    $us_name= explode("@",$row_sender_name['email']);
    $dir=$us_name[0];
    $file1 = explode("/", $row['file']);
    $file_name = $file1[2];
    $receiver_user_id = $row_sender_name['user_id'];
   ?>                                      

                                        <tr class="odd gradeX">

                                            <td class="center"><?php echo $receiver_user_id; ?></td>
                      
                                            <td class="center"><?php echo $sender_name; ?></td>

                                            <td class="center"><a href="<?php echo $site_url.$row['file']; ?>" target="_blank" ><?php echo htmlentities(stripslashes($file_name));?></a></td>

                                            <td class="center"><?php echo $row['subject']; ?></td>

                                              <td class="center"><?php echo htmlentities(stripslashes($row['upload_date']));?></td> 

                                              <td class="center"><?php echo htmlentities(stripslashes($row['expiry_date']));?></td>
  
                                            <td class="center">
                                              <?php echo htmlentities(stripslashes($row['remarks']));?>
                                            </td>
                                          
                                            <td class="center">
                                              <a href="forward.php?forwardfile=<?php echo htmlentities($file_name);?>"><button class="btn btn-primary">Forward file</button></a>
                                            </td>
                   

                                        </tr>

<?php $cnt++;}?>                                      

                                    </tbody>

                                </table>

                            </div>

                            

                        </div>

                    </div>

                    <!--End Advanced Tables -->

                </div>

            </div>            

    </div>

    </div>



     <!-- CONTENT-WRAPPER SECTION END-->

  <?php include('includes/footer.php');?>

      <!-- FOOTER SECTION END-->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->

    <!-- CORE JQUERY  -->

    <script src="<?php echo $site_url; ?>assets/js/jquery-1.10.2.js"></script>

    <!-- BOOTSTRAP SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/bootstrap.js"></script>

    <!-- DATATABLE SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/dataTables/jquery.dataTables.js"></script>

    <script src="<?php echo $site_url; ?>assets/js/dataTables/dataTables.bootstrap.js"></script>

      <!-- CUSTOM SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/custom.js"></script>

    <script type="text/javascript">
  //     $('#reject').click(function(){
  //       var a = document.getElementById("remark");
  //       if(a.value == "")
  //       {
  //         alert("Please Send your Remarks and then reject the file")
  //         event.preventDefault();
  //       }
  // });

  function reject(remark)
  {
        var a = document.getElementById(remark);
        if(a.value == "")
        {
          alert("Please Send your Remarks and then reject the file")
          event.preventDefault();
        }
  }
    </script>

</body>

</html>

<?php

 } 

?>
