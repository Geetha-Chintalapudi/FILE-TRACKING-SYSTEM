<?php
include('includes/config.php');
include('includes/functions.php');
session_start(); 

if(isset($_SESSION['ulogin']))
 {
  $sender_email = $_SESSION['ulogin'];
  $get_userid = "select * from users where email = '$sender_email'";
  $run_userid = mysqli_query($con, $get_userid);
  $row_userid = mysqli_fetch_array($run_userid);
  $sender_id = $row_userid['id'];
  $us_name= explode("@",$row_userid['email']);

  $name=$us_name[0];


 } 
  $del_notification = "update users set expire_noti = '' where email = '$sender_email'";
 $run_de_noti = mysqli_query($con, $del_notification);

 $update_noti_status = "update send_files set expire_noti_status = '0' where receiver = '$sender_id' && expire_noti_status = '1'";
 $run_noti_status = mysqli_query($con, $update_noti_status);
$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 60*60,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
unset($_SESSION['login']);
session_destroy(); // destroy session
header("location:index.php"); 
?>

