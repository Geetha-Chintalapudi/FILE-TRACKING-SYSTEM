<?php
session_start();
//$_SESSION['ulogin'] = "mohamed@riswan.com";
error_reporting(0);
include('includes/config.php');
include('includes/functions.php');


if(strlen($_SESSION['alogin'])==0 && strlen($_SESSION['ulogin'])==0)
{   
header('location:index.php');
}
else{ 

  

 if(isset($_SESSION['ulogin']))
 {
  $sender_email = $_SESSION['ulogin'];
  $get_userid = "select * from users where email = '$sender_email'";
  $run_userid = mysqli_query($con, $get_userid);
  $row_userid = mysqli_fetch_array($run_userid);
  $sender_id = $row_userid['id'];
  $us_name= explode("@",$row_userid['email']);

  $name=$us_name[0];


 } 

 $get_notification = "select expire_noti from users where email = '$sender_email'";
 $run_noti = mysqli_query($con, $get_notification);
 $row_noti = mysqli_fetch_array($run_noti);
			
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
   <title>File Sharing | Notifications</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Notifications</h4>
                
                            </div>

</div>
<div class="row">
<?php if($_SESSION['error']!="")
    {?>	
<div class="col-md-6">
<div class="alert alert-danger" >
 <strong>Error :</strong> 
 <?php echo htmlentities($_SESSION['error']);?>
<?php echo htmlentities($_SESSION['error']="");?>
</div>
</div>
<?php } ?>
<?php if($_SESSION['success']!="")
{?>
<div class="col-md-6">
<div class="alert alert-success" >
 <strong>Success :</strong> 
 <?php echo htmlentities($_SESSION['success']);?>
<?php echo htmlentities($_SESSION['success']="");?>
</div>
</div>
<?php } ?>
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Notifications
</div>
<div class="panel-body">
<form action="" role="form" method="post" enctype="multipart/form-data">
<div class="form-group">
  <?php echo "<h4>".str_replace(",", "<br><br>", $row_noti['expire_noti'])."</h4>"; ?>
</div>
</form>
 </div>
 </div>
 </div>
  </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="<?php echo $site_url; ?>assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo $site_url; ?>assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="<?php echo $site_url; ?>assets/js/custom.js"></script>
	
</body>

<script type="text/javascript">
  $("#name").bind('input', function () {
    if(checkExists( $('#name').val() ) === true){
        var value = $('#name').val();
        var user_id = $('#userlist [value="' + value + '"]').data('value');
        $("#loaderIcon").show();
        jQuery.ajax({
        url: "receiver_details.php",
        data:'u_id='+user_id,
        type: "POST",
        success:function(data){
        $("#result").html(data);
        $("#loaderIcon").hide();
        },
        error:function (){}
        });
    }
});

function checkExists(inputValue) {
    console.log(inputValue);
    
    var x = document.getElementById("userlist");
    var i;
    var flag;
    for (i = 0; i < x.options.length; i++) {
        if(inputValue == x.options[i].value){
            flag = true;
        }
    }
    return flag;
}  
</script>
</html>
<?php }  ?>
