<?php

session_start();

error_reporting(0);

include('includes/config.php');
include('includes/functions.php');
if(strlen($_SESSION['alogin'])==0 && strlen($_SESSION['ulogin'])==0)

  { 

header('location:index.php');

}

else { 

    ?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <meta name="description" content="" />

    <meta name="author" content="" />

    <!--[if IE]>

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <![endif]-->

    <title>File Sharing |  DashBoard</title>

    <!-- BOOTSTRAP CORE STYLE  -->

    <link href="assets/css/bootstrap.css" rel="stylesheet" />

    <!-- FONT AWESOME STYLE  -->

    <link href="assets/css/font-awesome.css" rel="stylesheet" />

	<!-- DATATABLE STYLE  -->

    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

    <!-- CUSTOM STYLE  -->

    <link href="assets/css/style.css" rel="stylesheet" />

    <!-- GOOGLE FONT -->

    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



</head>

<body>

      <!------MENU SECTION START-->

<?php include('includes/header.php');?>

<!-- MENU SECTION END-->

    <div class="col-lg-7 col-md-7 col-sm-9 content-wrapper">

         <div class="">

        <div class="row">

            <div class="col-md-12">

                <?php 
                    if(isset($_SESSION['ulogin']))
                    {
                        $login_user_email = $_SESSION['ulogin']; 
                        $sql = "SELECT * from users where email = '$login_user_email' ";
                        $run_sql =  mysqli_query($con,$sql);
                        $row = mysqli_fetch_array($run_sql);
                        $uid = $row['id'];


    $get_userid = "select * from users where email = '$login_user_email'";
    $run_userid = mysqli_query($con, $get_userid);
    
    $row_userid = mysqli_fetch_array($run_userid);
    $userid = $row_userid['id'];

    $get_date = "select * from send_files where receiver = '$userid' && expire_noti_status IS NULL";
    $run_date = mysqli_query($con, $get_date);
    while($row_date = mysqli_fetch_array($run_date))
    {
    // $userid = $row_date['id'];
    $file = explode("/",$row_date['file']);
    $file_name = $file[2];

    $date1=date_create($row_date['upload_date']);
    $date2=date_create($row_date['expiry_date']);
    $diff=date_diff($date1,$date2);
    $differ= $diff->format("%R%a days");
    $range=explode(" ", $differ);
    $splitday=explode("+", $range[0]);
      if($splitday[1] < 1)
      {
          $get_notification = "select expire_noti from users where email = '$login_user_email'";
         $run_noti = mysqli_query($con, $get_notification);
         $row_noti = mysqli_fetch_array($run_noti);
         if($row_noti['expire_noti'] == "")
         {
            $noti_msg = "File named as ".$file_name." was Expired";
         }
         else if($row_noti['expire_noti'] != "")
         {
            $noti_msg = $row_noti['expire_noti'].", File named as ".$file_name." was Expired";
         }
         
         $send_noti = "update users set expire_noti = '$noti_msg' where email = '$login_user_email'";
         $run_send_noti = mysqli_query($con, $send_noti);

         $update_noti_status = "update send_files set expire_noti_status = '1' where receiver = '$userid'";
         $run_noti_status = mysqli_query($con, $update_noti_status);
      }
  }
                ?>

                <h4 class="header-line">WELCOME USER <strong><?php echo $row['user_name']; ?></strong></h4>
                    
                    

            <?php } else if(isset($_SESSION['alogin']))
            {
                ?>
                <h4 class="header-line">ADMIN DASHBOARD</h4>
                <div class="col-md-6 col-sm-6 col-xs-12">
                      <div class="alert alert-success back-widget-set text-center" style="background: #02008e;">
                            <i class="fa fa-users" aria-hidden="true" style="font-size: 40px; color: #fff;"></i>
                        <?php 
                        $sql ="SELECT id from users";
                        $run_sql = mysqli_query($con,$sql);
                        $listdbooks = mysqli_num_rows($run_sql);
                        ?>


                            <h3 style="color: #fff;"><?php echo htmlentities($listdbooks);?></h3>
                      <h3 style="color: #fff;">Users Registered</h3>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <div class="alert alert-success back-widget-set text-center" style="background: #3c763d;">
                            <i class="fa fa-file" aria-hidden="true" style="font-size: 40px; color: #fff;"></i>
                        <?php 
                        $sql ="SELECT id from send_files";
                        $run_sql = mysqli_query($con,$sql);
                        $listdbooks = mysqli_num_rows($run_sql);
                        ?>


                            <h3 style="color: #fff;"><?php echo htmlentities($listdbooks);?></h3>
                      <h3 style="color: #fff;">Files Transfered</h3>
                        </div>
                    </div>
            <?php } ?>
            

           </div>

        </div>

     

                </div>

            </div>

         

    </div>

    </div>

     <!-- CONTENT-WRAPPER SECTION END-->

<?php include('includes/footer.php');?>

      <!-- FOOTER SECTION END-->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->

    <!-- CORE JQUERY  -->

    <script src="assets/js/jquery-1.10.2.js"></script>

    <!-- BOOTSTRAP SCRIPTS  -->

    <script src="assets/js/bootstrap.js"></script>

	<!-- DATATABLE SCRIPTS  -->

    <script src="assets/js/dataTables/jquery.dataTables.js"></script>

    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>

      <!-- CUSTOM SCRIPTS  -->

    <script src="assets/js/custom.js"></script>

</body>

</html>

<?php } ?>

