<?php
session_start();
error_reporting(0);
include('includes/config.php');
$target_dir = "../images/site_logo/";
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 
if(isset($_GET['msg']))
{
	$id=$_GET['msg'];
	$id=$_SESSION['success']="Site Settings Updated Successfully";
}
else if(isset($_GET['emsg']))
{
	$id=$_GET['emsg'];
	$id=$_SESSION['error']="Site Settings Not Updated ";
}
$sql = "SELECT * from site_setting";
$cnt=1;
$run_sql = 	mysqli_query($con,$sql);
$row = mysqli_fetch_array($run_sql);
$file = $row['logo'];
$desc = $row['site_title'];
$pro_cat = $row['email'];
$pro_sup = $row['phone'];
$tax = $row['address'];
$tax_method = $row['working_hours_from'];
$cost = $row['working_hours_to'];
$sell = $row['fb_url'];
$insta_url = $row['insta_url'];
$twitter_url = $row['twitter_url'];
$qty = $row['footer_copyright'];
$file1 = $row['c_image'];
if(isset($_POST['update']))
{
$name = $_POST['pro_name'];
$desc = $_POST['pro_desc'];
$pro_cat = $_POST['pro_cat'];
$pro_sup = $_POST['tax'];
$tax = $_POST['cost'];
$tax_method = $_POST['sell'];
$cost = $_POST['whto'];
$sell = $_POST['fburl'];
$insta_url = $_POST['insta_url'];
$twitter_url = $_POST['twitter_url'];
$qty = $_POST['copyright'];
$filename=basename($_FILES["application"]["name"]);
$filename1=basename($_FILES["application1"]["name"]);
$target_file = $target_dir . $filename;
$target_file1 = $target_dir . $filename1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$imageFileType = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
$check = getimagesize($_FILES["application"]["tmp_name"]);
$check1 = getimagesize($_FILES["application1"]["tmp_name"]);
if($filename=="")
{
	$filename = $file;
}
/*if($filename1=="")
{
	$filename1 = $file1;
}*/
// Check if $uploadOk is set to 0 by an error
		move_uploaded_file($_FILES["application"]["tmp_name"], $target_file);
		//move_uploaded_file($_FILES["application1"]["tmp_name"], $target_file1);
			 $update_sql="update site_setting set site_title='$name',email='$desc',phone='$pro_sup',address='$tax',working_hours_from='$tax_method',working_hours_to='$cost',insta_url='$insta_url',twitter_url='$twitter_url',fb_url='$sell',footer_copyright='$qty',logo='$filename'";
if($run_update_sql = mysqli_query($con,$update_sql))
	{
		header('location:site_settings.php?msg=mymsg');
	}
	else
	{
		header('location:site_settings.php?emsg=msg');
	}
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Smileyvart | Site Settings</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Edit Site Settings</h4>
                            </div>
</div>
<div class="row">
<?php if($_SESSION['error']!="")
    {?>	
<div class="col-md-6">
<div class="alert alert-danger" >
 <strong>Error :</strong> 
 <?php echo htmlentities($_SESSION['error']);?>
<?php echo htmlentities($_SESSION['error']="");?>
</div>
</div>
<?php } ?>
<?php if($_SESSION['success']!="")
{?>
<div class="col-md-6">
<div class="alert alert-success" >
 <strong>Success :</strong> 
 <?php echo htmlentities($_SESSION['success']);?>
<?php echo htmlentities($_SESSION['success']="");?>
</div>
</div>
<?php } ?>
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Site Info
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">
<div class="form-group">
	<label>Site Title<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="pro_name" autocomplete="off"  value="<?php echo $desc; ?>" required />
</div>
<div class="form-group">
	<label>Email<span style="color:red;">*</span></label>
	<input class="form-control" type="email" name="pro_desc" autocomplete="off"  value="<?php echo $pro_cat; ?>" required />
</div>
<div class="form-group">
	<label>phone<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="tax" autocomplete="off"  value="<?php echo $pro_sup; ?>" required />
</div>
<div class="form-group">
	<label>Address<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="cost" autocomplete="off"  value="<?php echo $tax; ?>" required />
</div>
<div class="form-group">
	<label>Working_Hours_From<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="sell" autocomplete="off"  value="<?php echo $tax_method; ?>" required />
</div>
<div class="form-group">
	<label>Working_Hours_To<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="whto" autocomplete="off"  value="<?php echo $cost; ?>" required />
</div>
<div class="form-group">
	<label>Facebook Url<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="fburl" autocomplete="off"  value="<?php echo $sell; ?>" required />
</div>
<div class="form-group">
	<label>Youtube Video Link URL<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="insta_url" autocomplete="off"  value="<?php echo $insta_url; ?>" required />
</div>
<div class="form-group">
	<label>Youtube Channel URL<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="twitter_url" autocomplete="off"  value="<?php echo $twitter_url; ?>" required />
</div>
<div class="form-group">
	<label>footer_copyright<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="copyright" autocomplete="off"  value="<?php echo $qty; ?>" required />
</div>
<div class="form-group">
	<label>Site Logo<span style="color:red;">*</span></label><br>
  <img src="<?php echo $target_dir.$file;?>" alt="smiley image" height="120" width="250">
</div>
<div class="form-group">
	<label>Change Logo<span style="color:red;">*</span></label><br>
 <input type="file" name="application" >
 </div>
 <!--div class="form-group">
	<label>Contact Page image<span style="color:red;">*</span></label><br>
  <img src="site_logo/<?php echo $file1;?>" alt="smiley LOGO" height="120" width="250">
</div>
\
<div class="form-group">
	<label>Change Page image<span style="color:red;">*</span></label><br>
 <input type="file" name="application1" >
 </div-->
 <?php } ?>
<button type="submit" name="update" class="btn btn-info">Update </button>
                </form>
    </div>
</div>
    </div>
        </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php  ?>
