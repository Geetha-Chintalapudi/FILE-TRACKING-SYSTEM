<?php
session_start();

error_reporting(0);
include('includes/config.php');
include('includes/functions.php');


if(strlen($_SESSION['alogin'])==0)
{   
header('location:index.php');
}
else{ 
			
?>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

    <meta name="description" content="" />

    <meta name="author" content="" />

    <title>File Sharing| Transfered Files</title>

    <!-- BOOTSTRAP CORE STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/bootstrap.css" rel="stylesheet" />

    <!-- FONT AWESOME STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/font-awesome.css" rel="stylesheet" />

    <!-- DATATABLE STYLE  -->

    <link href="<?php echo $site_url; ?>assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />

    <!-- CUSTOM STYLE  -->

    <link href="<?php echo $site_url; ?>assets/css/style.css" rel="stylesheet" />

    <!-- GOOGLE FONT -->

    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />



</head>

<body>

      <!------MENU SECTION START-->

<?php include('includes/header.php');?>

<!-- MENU SECTION END-->

        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">

         <div class="">

        <div class="row">

            <div class="col-md-12">

                <h4 class="header-line">Transfered Files</h4>

    </div>

     <div class="row">

    <?php if($_SESSION['error']!="")

    {?>

<div class="col-md-6">

<div class="alert alert-danger" >

 <strong>Error :</strong> 

 <?php echo htmlentities($_SESSION['error']);?>

<?php echo htmlentities($_SESSION['error']="");?>

</div>

</div>

<?php } ?>

<?php if($_SESSION['msg']!="")

{?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['msg']);?>

<?php echo htmlentities($_SESSION['msg']="");?>

</div>

</div>

<?php } ?>

<?php if($_SESSION['updatemsg']!="")

{?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['updatemsg']);?>

<?php echo htmlentities($_SESSION['updatemsg']="");?>

</div>

</div>

<?php } ?>





   <?php if($_SESSION['delmsg']!="")

    {?>

<div class="col-md-6">

<div class="alert alert-success" >

 <strong>Success :</strong> 

 <?php echo htmlentities($_SESSION['delmsg']);?>

<?php echo htmlentities($_SESSION['delmsg']="");?>

</div>

</div>

<?php } ?>



</div>

        </div>

            <div class="row">

                <div class="col-md-12">

                    <!-- Advanced Tables -->

                    <div class="panel panel-default">

                        <div class="panel-heading">

                           Transfered Files

                        </div>

                        <div class="panel-body">

                            <div class="table-responsive">

                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">

                                    <thead>

                                        <tr>

                                            <th>Sender Id</th>

                                            <th>Receiver Id</th>

                                            <th>File</th>

                                            <th>Upload Date</th>

                                            <th>Expiry Date</th>

                                            <th>Status</th>

                                            <th>Remarks</th>

                                        </tr>

                                    </thead>

                                    <tbody>



<?php $sql = "SELECT * from send_files";

  $run_sql =  mysqli_query($con,$sql);

  $cnt = 1;

  while($row = mysqli_fetch_array($run_sql))

{
  $sender = $row['sender'];
  $receiver = $row['receiver'];
  $get_user_id_sender = "select user_id,user_name from users where id = '$sender'";
  $run_user_id_sender = mysqli_query($con, $get_user_id_sender);
  $row_user_id_sender = mysqli_fetch_array($run_user_id_sender);
  $sender_user_id = $row_user_id_sender['user_id'];

  $get_user_id_receiver = "select user_id,user_name from users where id = '$receiver'";
  $run_user_id_receiver = mysqli_query($con, $get_user_id_receiver);
  $row_user_id_receiver = mysqli_fetch_array($run_user_id_receiver);
  $receiver_user_id = $row_user_id_receiver['user_id'];


   ?>                                      

                                        <tr class="odd gradeX">

                                            <td class="center"><?php echo $sender_user_id; ?></td>
                      
                                            <td class="center"><?php echo $receiver_user_id; ?></td>

                                            <td class="center"><a href="<?php echo $site_url.$row['file']; ?>" target="_blank" ><i class="fa fa-file" aria-hidden="true"></i></a></td>

                                              <td class="center"><?php echo $row['upload_date']; ?></td> 

                                              <td class="center"><?php echo $row['expiry_date']; ?></td> 

                                              <?php if($row['status'] == "no") { ?>
                                              <td class="center">Not Seen</td> 
                                            <?php } ?>
                                            <?php if($row['status'] == "accept") { ?>
                                              <td class="center">Accepted</td> 
                                            <?php } ?>
                                            <?php if($row['status'] == "reject") { ?>
                                              <td class="center">Rejected</td> 
                                            <?php } ?>

                                            <td class="center"><?php echo $row['remarks']; ?></td>

                                        </tr>

<?php $cnt++;}?>                                      

                                    </tbody>

                                </table>

                            </div>

                            

                        </div>

                    </div>

                    <!--End Advanced Tables -->

                </div>

            </div>            

    </div>

    </div>



     <!-- CONTENT-WRAPPER SECTION END-->

  <?php include('includes/footer.php');?>

      <!-- FOOTER SECTION END-->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->

    <!-- CORE JQUERY  -->

    <script src="<?php echo $site_url; ?>assets/js/jquery-1.10.2.js"></script>

    <!-- BOOTSTRAP SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/bootstrap.js"></script>

    <!-- DATATABLE SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/dataTables/jquery.dataTables.js"></script>

    <script src="<?php echo $site_url; ?>assets/js/dataTables/dataTables.bootstrap.js"></script>

      <!-- CUSTOM SCRIPTS  -->

    <script src="<?php echo $site_url; ?>assets/js/custom.js"></script>

    <script type="text/javascript">
  //     $('#reject').click(function(){
  //       var a = document.getElementById("remark");
  //       if(a.value == "")
  //       {
  //         alert("Please Send your Remarks and then reject the file")
  //         event.preventDefault();
  //       }
  // });

  function reject(remark)
  {
        var a = document.getElementById(remark);
        if(a.value == "")
        {
          alert("Please Send your Remarks and then reject the file")
          event.preventDefault();
        }
  }
    </script>

</body>

</html>

<?php

 } 

?>
