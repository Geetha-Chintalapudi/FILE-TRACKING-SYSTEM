<?php
session_start();
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0 || !isset($_GET['user']))
{   
header('location:index.php');
}
else{

$userid = $_GET['user'];
$sql = "SELECT * from users where id = '$userid' ";
$run_sql =  mysqli_query($con,$sql);
$row1 = mysqli_fetch_array($run_sql);

if(isset($_POST['update']))
{
    $username=addslashes($_POST['uname']);
    $dept_code=addslashes($_POST['udepart_code']);
    $position=addslashes($_POST['upostion']);

    $collegename=addslashes($_POST['collegename']);
    $collegecode=addslashes($_POST['collegecode']);
    $dept_name=$_POST['dept_name'];
    
    $update_user = "update users set user_name = '$username', dept_code = '$dept_code', posistion = '$position', collegename = '$collegename', collegecode = '$collegecode', dept_name = '$dept_name' where id = '$userid'";
    if($run_update_user = mysqli_query($con, $update_user))
    {
        echo '<script>alert("Profile Updated");window.location.href="users.php";</script>';
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>File Sharing  | Edit User Details</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">User Details</h4>
                            </div>
</div>
<!-- <div class="row">
<?php i//f( $_SESSION['error']!="")  { 
    ?>	
<div class="col-md-6">
<div class="alert alert-danger" >
 <strong>Error :</strong> 
 <?php //echo htmlentities($_SESSION['error']);?>
<?php  //echo htmlentities($_SESSION['error']="");?>
</div>
</div>
<?php //} ?> -->
<?php // if($_SESSION['success']!="")
//{?>
<!-- <div class="col-md-6">
<div class="alert alert-success" >
 <strong>Success :</strong> 
 <?php //echo htmlentities($_SESSION['success']);?>
<?php //echo htmlentities($_SESSION['success']="");?>
</div>
</div> -->
<?php // } ?>
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Edit User Details
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">
<div class="form-group">
                            <label>Username<span style="color:red;">*</span></label>
                            <input class="form-control" type="text" name="uname" autocomplete="off"  required value="<?php echo $row1['user_name']; ?>" />
                        </div>
                        <div class="form-group">
                            <label>Email<span style="color:red;">*</span></label>
                            <input class="form-control" type="email" name="uemail" autocomplete="off" required value="<?php echo $row1['email']; ?>" disabled="" />
                        </div>
                        <div class="form-group">
                            <label>Department Name<span style="color:red;">*</span></label>
                            <input class="form-control" type="text" name="dept_name" autocomplete="off"   required value="<?php echo $row1['dept_name']; ?>" />
                        </div>

                        <div class="form-group">
                            <label>Department Code<span style="color:red;">*</span></label>
                            <input class="form-control" type="text" name="udepart_code" autocomplete="off"   required value="<?php echo $row1['dept_code']; ?>" />
                        </div>
                        <div class="form-group">
                            <label>Position<span style="color:red;">*</span></label><br>
                            <select class="form-control" name="upostion" >
                                <option <?php if($row1['posistion']=='Hod'){ echo "selected"; }  ?>value="Hod">HOD</option>
                                <option <?php if($row1['posistion']=='Principal'){ echo "selected"; }  ?> value="Principal">Principal</option>
                            </select>
                            
                        </div>
                        <div class="form-group">
                            <label>College Name<span style="color:red;">*</span></label>
                            <input class="form-control" type="text" name="collegename" autocomplete="off" required value="<?php echo $row1['collegename']; ?>" />
                        </div>
                        <div class="form-group">
                            <label>College Code<span style="color:red;">*</span></label>
                            <input class="form-control" type="text" name="collegecode" autocomplete="off"   required value="<?php echo $row1['collegecode']; ?>" />
                        </div>
<button type="submit" name="update" class="btn btn-info">UPDATE</button>
                </form>
    </div>
</div>
    </div>
        </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php }  ?>
