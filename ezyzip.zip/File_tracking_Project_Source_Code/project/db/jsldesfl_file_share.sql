-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 30, 2020 at 02:20 PM
-- Server version: 5.6.41-84.1-log
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jsldesfl_file_share`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Anuj Kumar', 'phpgurukulofficial@gmail.com', 'admin@admin.com', '1e48c4420b7073bc11916c6c1de226bb', '2020-03-27 10:22:33');

-- --------------------------------------------------------

--
-- Table structure for table `send_files`
--

CREATE TABLE `send_files` (
  `id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'no',
  `remarks` text,
  `upload_date` date DEFAULT NULL,
  `expiry_date` varchar(255) DEFAULT NULL,
  `file_status` varchar(255) NOT NULL DEFAULT 'Active',
  `daterange` varchar(255) DEFAULT NULL,
  `noti` bigint(20) NOT NULL DEFAULT '0',
  `subject` text,
  `expire_noti_status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `send_files`
--

INSERT INTO `send_files` (`id`, `sender`, `receiver`, `file`, `status`, `remarks`, `upload_date`, `expiry_date`, `file_status`, `daterange`, `noti`, `subject`, `expire_noti_status`) VALUES
(40, 28, 29, 'files/ajmal/1.jpg', 'no', NULL, '2020-03-27', '2020-03-31', 'Active', NULL, 1, NULL, NULL),
(39, 26, 28, 'files/mohamed/1.jpg', 'accept', NULL, '2020-03-27', '2020-03-29', 'Active', NULL, 1, NULL, NULL),
(38, 26, 27, 'files/mohamed/1.jpg', 'accept', NULL, '2020-03-27', '2020-03-27', 'Active', NULL, 0, NULL, NULL),
(41, 30, 31, 'files/geetha/deloitte-nl-data-analyse-student-analytics-fact-based-student-services.pdf', 'accept', 'ok', '2020-03-27', '2020-04-03', 'Active', NULL, 1, NULL, NULL),
(42, 34, 33, 'files/dheeraj/hello.docx', 'accept', 'forwarded to registrar', '2020-03-28', '2020-03-30', 'Active', NULL, 1, NULL, NULL),
(43, 33, 34, 'files/arun/hello1.docx', 'reject', NULL, '2020-03-28', '2020-03-29', 'Active', NULL, 1, NULL, NULL),
(44, 29, 26, 'files/deen/1.jpg', 'accept', NULL, '2020-03-30', '2020-03-29', 'Active', NULL, 1, 'Flag', 0),
(45, 29, 26, 'files/deen/04-maxwells.w710.h473.jpg', 'accept', NULL, '2020-03-30', '2020-03-28', 'Active', NULL, 1, 'shop', 0),
(47, 29, 26, 'files/deen/Chrysanthemum.jpg', 'no', NULL, '2020-03-30', '2020-03-31', 'Active', NULL, 1, 'TEST', NULL),
(48, 29, 28, 'files/deen/Chrysanthemum.jpg', 'no', NULL, '2020-03-30', '2020-03-31', 'Active', NULL, 1, 'TEST', NULL),
(50, 28, 26, 'files/ajmal/1.jpg', 'no', NULL, '2020-03-30', '2020-03-31', 'Active', NULL, 1, 'TEST FORWARD', NULL),
(51, 28, 29, 'files/ajmal/1.jpg', 'accept', NULL, '2020-03-30', '2020-03-31', 'Active', NULL, 1, 'TEST FORWARD', NULL),
(52, 28, 35, 'files/ajmal/1.jpg', 'no', NULL, '2020-03-30', '2020-03-31', 'Active', NULL, 1, 'TEST FORWARD', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `site_setting`
--

CREATE TABLE `site_setting` (
  `id` int(11) NOT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `site_title` text,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` longtext,
  `working_hours_from` varchar(255) DEFAULT NULL,
  `working_hours_to` varchar(255) DEFAULT NULL,
  `fb_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `insta_url` varchar(255) DEFAULT NULL,
  `c_image` varchar(255) DEFAULT NULL,
  `footer_copyright` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `site_setting`
--

INSERT INTO `site_setting` (`id`, `logo`, `site_title`, `email`, `phone`, `address`, `working_hours_from`, `working_hours_to`, `fb_url`, `twitter_url`, `insta_url`, `c_image`, `footer_copyright`) VALUES
(1, 'logo.jpg', 'Smileyvart', 'smileyvart@gmail.com', '+9194433 12345', 'smiley vart address', '08.am', '04.pm', 'https://www.facebook.com/smileyvart/74517248559483/', '#', '#', 'about_page_banner.png', 'Copyright 2019 smileyvart All Rights Reserved.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `u_password` varchar(255) DEFAULT NULL,
  `dept_code` varchar(255) DEFAULT NULL,
  `posistion` mediumtext,
  `collegename` longtext,
  `collegecode` longtext,
  `register_date` datetime DEFAULT NULL,
  `dept_name` varchar(255) DEFAULT NULL,
  `expire_noti` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_id`, `email`, `u_password`, `dept_code`, `posistion`, `collegename`, `collegecode`, `register_date`, `dept_name`, `expire_noti`) VALUES
(26, 'riswan', ' 26-100-102-2020-03-27 06:02:24', 'mohamed@riswan.com', '1e48c4420b7073bc11916c6c1de226bb', '100', 'Hod', 'abc', '102', '2020-03-27 06:02:24', 'eee', ''),
(27, 'yasar', ' 27-100-200-2020-03-27 06:02:54', 'y@g.com', '1e48c4420b7073bc11916c6c1de226bb', '100', 'Hod', 'xyz', '200', '2020-03-27 06:02:54', 'ece', NULL),
(28, 'ajmal', ' 28-136-369-2020-03-27 08:47:29', 'ajmal@a.com', '1e48c4420b7073bc11916c6c1de226bb', '136', 'Hod', 'sdf', '369', '2020-03-27 08:47:29', 'cse', ''),
(29, 'deen', ' 29-587-789-2020-03-27 09:04:26', 'deen@d.com', 'b59c67bf196a4758191e42f76670ceba', '587', 'Hod', 'aws', '789', '2020-03-27 09:04:26', 'mech', ''),
(30, 'geetha', ' 30-23-2020-2020-03-27 17:17:56', 'geetha@gmail.com', '1e48c4420b7073bc11916c6c1de226bb', '23', 'Hod', 'aknu', '2020', '2020-03-27 17:17:56', 'cse', NULL),
(31, 'bose', ' 31-24-2021-2020-03-27 17:21:30', 'bose@gmail.com', '1e48c4420b7073bc11916c6c1de226bb', '24', 'Hod', 'aknu', '2021', '2020-03-27 17:21:30', 'ece', NULL),
(32, 'm@gmail. com', ' 32-1001-T01-2020-03-28 11:35:10', 'm@gmail.com', '1e48c4420b7073bc11916c6c1de226bb', '1001', 'HOD', 'TPG', 'T01', '2020-03-28 11:35:10', 'CSE', NULL),
(33, 'arun', ' 33-1001-tpg02-2020-03-28 11:45:38', 'arun@gmail.com', '1e48c4420b7073bc11916c6c1de226bb', '1001', 'Hod', 'tpg1', 'tpg02', '2020-03-28 11:45:38', 'cse', NULL),
(34, 'Dheeraj', ' 34-1001-tpg02-2020-03-28 11:47:41', 'dheeraj@gmail.com', '1e48c4420b7073bc11916c6c1de226bb', '1001', 'Principal', 'tpg1', 'tpg02', '2020-03-28 11:47:41', 'cse', NULL),
(35, 'arshath', ' 35-456-639-2020-03-29 12:06:57', 'a@a.com', '1e48c4420b7073bc11916c6c1de226bb', '456', 'Hod', 'oiu', '639', '2020-03-29 12:06:57', 'hsc', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `send_files`
--
ALTER TABLE `send_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_setting`
--
ALTER TABLE `site_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `send_files`
--
ALTER TABLE `send_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `site_setting`
--
ALTER TABLE `site_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
