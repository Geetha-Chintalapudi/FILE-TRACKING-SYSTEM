<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/functions.php');


if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

$subdir="../images/product_images/";

$id1=$_GET['sid'];

 $sql = "SELECT * from products where id='$id1'";

$uploaded=0;
$run_sql = 	mysqli_query($con,$sql);

$p_row = mysqli_fetch_array($run_sql);

 $catid=stripslashes($p_row['cat_id']);
 $sub_cat_id=stripslashes($p_row['sub_cat_id']);
 $p_name=stripslashes($p_row['p_name']);
 $short_desc=stripslashes($p_row['short_desc']);
 $long_desc=stripslashes($p_row['long_desc']);
 $reg_price=stripslashes($p_row['reg_price']);
 $sale_price=stripslashes($p_row['sale_price']);
 $prime_price=stripslashes($p_row['prime_price']);
  $batch=stripslashes($p_row['batch']);
  $quan_tity=stripslashes($p_row['quantity']);
  $tax_rate=stripslashes($p_row['tax_rate']);
   $featimage=$p_row['feature_image'];
   $image_1=$p_row['image1'];
   $image_2=$p_row['image2'];
 $skau_id=$p_row['skau_id'];
 $f_weight=stripslashes($p_row['weight']);

$cat_sql="SELECT * from categories where id='$catid'";
$run_catsql=mysqli_query($con,$cat_sql);
$catrows=mysqli_fetch_array($run_catsql);

$subcat_sql="SELECT * from subcategories where id='$sub_cat_id'";
$run_subcat_sql=mysqli_query($con,$subcat_sql);
$subcatrows=mysqli_fetch_array($run_subcat_sql);

if(isset($_POST['update']))
{
	 $categories=$_POST['categories'];
	 $cat=explode("-",$categories);
	 $cat_id=$cat[0];
    $sub_category=$_POST['sub_category'];
	 $sub=explode("-",$sub_category);
	 $sub_id=$sub[0]; 
	
	$p_name=addslashes($_POST['p_name']);
	$short_desc=addslashes($_POST['short_desc']);
	$long_desc=addslashes($_POST['long_desc']);
	$reg_price=addslashes($_POST['reg_price']);
	$sale_price=addslashes($_POST['sale_price']);
	$prime_price=addslashes($_POST['prime_price']);
	$skau_id=addslashes($_POST['skau_id']);
	$weight=addslashes($_POST['weight']);
	$batchvalue=addslashes($_POST['batchvalue']);
	$taxrate=addslashes($_POST['taxrate']);
	$quantity=addslashes($_POST['quantity']);
	$is_home = (isset($_POST['display'])) ? 1 : 0;
	$bestdisplay = (isset($_POST['bestdisplay'])) ? 1 : 0;
	 $folder_path=$p_row['feature_image'];
	 $splitfolder=explode("/",$folder_path);
	 $folder=$splitfolder[0];
	 $old_feat_img_name=$splitfolder[1];

	$img1=$p_row['image1'];
	$splitimg1=explode("/",$img1);
	$image1=$_FILES["img_1"]["name"];
	 $img1_name=$splitimg1[1];
    $im1=basename($image1);
    $im2=basename($image2);
   


	$img2=$p_row['image2'];
	
	$splitimg2=explode("/",$img2);
	 $img2_name=$splitimg2[1];
	 
	  mkdir("../images/product_images/thumbnails");
	 
	 $target_dir="../images/product_images/".$folder."/";
	  
	 $featureimage=$_FILES["f_image"]["name"];
	
	$image2=$_FILES["img_2"]["name"];
	
	
			

	if(basename($featureimage)!=$old_feat_img_name)
	{
		if(empty($featureimage))
			{
				 $featureimage=$featimage;
				
				
			}else
			{
		$upload_img = cwUpload('f_image','../images/product_images/thumbnails/','',TRUE,$target_dir,'200','200');
	   unlink($target_dir.$old_feat_img_name);
			}
	}
	
	
	if(basename($im1)!=$img1_name)
	{
		if(empty($image1))
			{
				 $image1=$image_1;
				
				
			}else
			{
		$upload_img1 = cwUpload('img_1','../images/product_images/thumbnails/','',TRUE,$target_dir,'200','200');
	   unlink($target_dir.$img1_name);
			}
	}
	
	
	
	if(basename($im2)!=$img2_name)
	{
		
		//unlink($target_dir.$img2_name,true);
		//move_uploaded_file($_FILES["image2"]["tmp_name"], $target_file2);
		if(empty($image2))
			{
				 $image2=$image_2;
				
				
			}else
			{
		$upload_img2 = cwUpload('img_2','../images/product_images/thumbnails/','',TRUE,$target_dir,'200','200');
	   unlink($target_dir.$img2_name);
			}
	}
	
	
	
	$jpeg = glob("../images/product_images/thumbnails/*.jpg");
		foreach($jpeg as $jpegimg){
			 @unlink($jpegimg);
		}
		$png = glob("../images/product_images/thumbnails/*.png");
		foreach($png as $pngimg){
			 @unlink($pngimg);
		}
	
	rmdir('../images/product_images/thumbnails');
	
	$path=$folder."/". basename($featureimage);
	 $path1=$folder."/". basename($image1);
	 $path2=$folder."/". basename($image2);
	 
	 
	 
	 if($featureimage=="")
	 {
		
		 $path=$p_row['feature_image'];
		
	 }
	  if(empty($image1))
	  {
		    $path1=$p_row['image1'];
		  
	  }
	  
	  if(empty($image2))
	  {
		    $path2=$p_row['image2'];
		  
	  }
	
		
		 $update_sql="update products set p_name='$p_name',short_desc='$short_desc',long_desc='$long_desc',reg_price='$reg_price',sale_price='$sale_price',prime_price='$prime_price',weight='$weight',feature_image='$path',image1='$path1',image2='$path2',skau_id='$skau_id',is_feature='$is_home' ,cat_id='$cat_id',sub_cat_id='$sub_id', batch='$batchvalue', bestseller='$bestdisplay',quantity='$quantity',tax_rate='$taxrate' WHERE id='$id1'";
		 
		       
             if (mysqli_query($con, $update_sql)) {
		       
			  header('location:manage_products.php');
				} 
				else {
				echo "Error: " . $sql . "<br>" . mysqli_error($con);
				}
	
	
	  		 
         //print_r($errors);
     

}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Smileyvart| Update products</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Update Products Settings</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Update Products Info
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">


<div class="form-group">

	<label>Categories <span style="color:red;">*</span></label><br>
	  <input list="category" value="<?php echo $catrows['id']."-".$catrows['cat_name'];?>" class="form-control" name="categories"  id="categories" placeholder="Select Category" >
		<datalist id="category">
			
				<?php 
		        $catsql = "SELECT * from categories ";
				$run_catsql = 	mysqli_query($con,$catsql);
				while($row = mysqli_fetch_array($run_catsql))
				{        
	             ?>                                      
              <option value="<?php  echo $row['id']."-".$row['cat_name']; ?>" ><?php echo $row['cat_name']; ?></option>
  
              <?php }?>
 
            </datalist>
</div>


<div class="form-group" id="sub_div">

	<label>Subcategories <span style="color:red;">*</span></label><br>
	 <input class="form-control" value="<?php echo $subcatrows['id']."-".$subcatrows['sub_cat_name']; ?>" list="subcategory" name="sub_category"  placeholder="Select Subcategory" >
		<datalist id="subcategory" >
		<?php 
		      echo  $subsql = "SELECT * from subcategories";
				$run_subsql = 	mysqli_query($con,$subsql);
				while($srow = mysqli_fetch_array($run_subsql))
				{  ?>
            <option value="<?php echo $srow['id']."-".$srow['sub_cat_name']; ?>" ></option>
			
				<?php  }?>
            </datalist>
</div>


<div class="form-group">
<label> Product Name<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="p_name" value="<?php echo $p_name; ?>" autocomplete="off"  required />
</div>

<div class="form-group">
<label> Short Description<span style="color:red;">*</span></label>
<textarea class="form-control" name="short_desc" maxlength="150" placeholder="Product Short Description" ><?php echo $short_desc; ?> </textarea>

</div>

<div class="form-group">
<label> Long Description<span style="color:red;">*</span></label>
<textarea class="form-control" name="long_desc" maxlength="500" placeholder="Product Long Description" ><?php echo $long_desc; ?> </textarea>
</div>

<div class="form-group">
<label> Regular Price<span style="color:red;">*</span></label>
<input class="form-control" type="number" name="reg_price" autocomplete="off"  value="<?php echo $reg_price; ?>" required />
</div>

<div class="form-group">
<label> Sale Price<span style="color:red;">*</span></label>
<input class="form-control" type="number" name="sale_price" autocomplete="off"  value="<?php echo $sale_price; ?>" required />
</div>

<div class="form-group">
<label> Prime Price<span style="color:red;">*</span></label>
<input class="form-control" type="number" name="prime_price" autocomplete="off"  value="<?php echo $prime_price; ?>" required />
</div>

<div class="form-group">
<label> Coins<span style="color:red;">*</span></label>
<input class="form-control" type="number" name="skau_id" autocomplete="off"  value="<?php echo $skau_id; ?>" required />
</div>

<div class="form-group">
<label> Product Weight In Grams<span style="color:red;">*</span></label>
<input class="form-control" type="number" name="weight" autocomplete="off"  value="<?php echo $f_weight; ?>" required />
</div>

<div class="form-group">
<label> Product Batch<span style="color:red;">*</span></label>
<input class="form-control" type="text" name="batchvalue" value="<?php echo $batch; ?>" autocomplete="off"   />
</div>

<div class="form-group">
<label> Product Quantity<span style="color:red;">*</span></label>
<input class="form-control" type="number" name="quantity" autocomplete="off"  value="<?php echo $quan_tity; ?>"  />
</div>


<div class="form-group">
<label>Tax  (Tax Seperated By ',' comma's)<span style="color:red;">*</span></label>
<textarea class="form-control" name="taxrate" maxlength="700" placeholder="Product Long Description" required ><?php echo $tax_rate; ?> </textarea>
</div>

<div class="form-group">

	<label> Display In Page<span style="color:red;">*</span></label><br>

	<?php  if($p_row['is_feature']==1) {?>

	<input type="checkbox" name="display" value="1" checked required> Display In Page<br>

	<?php } else

	{
		?>

		<input type="checkbox" name="display" value="0" > Display In HomePage<br>

	<?php } ?>

</div>

<div class="form-group">

	<label> Display In BestSeller<span style="color:red;">*</span></label><br>

	<?php  if($p_row['bestseller']==1) {?>

	<input type="checkbox" name="bestdisplay" value="1" checked required> Display In Page<br>

	<?php } else

	{
		?>

		<input type="checkbox" name="bestdisplay" value="0" > Display In HomePage<br>

	<?php } ?>

</div>

<div class="form-group">
<label>Feature Image<span style="color:red;">*</span></label><br>
<img src="<?php echo $subdir.$featimage;?>" alt="feature_image " height="auto" width="30%">
</div>

<div class="form-group">
<label>Update Feature Image<span style="color:red;">*</span></label>
<input  type="file" name="f_image"   />
</div>

<div class="form-group">
<label>Image1<span style="color:red;">*</span></label><br>
<img src="<?php echo $subdir.$image_1;?>" alt="image1 " height="auto" width="30%">
</div>

<div class="form-group">
<label>Upload Image 1<span style="color:red;">*</span></label>
<input  type="file" name="img_1"   />
</div>

<div class="form-group">
<label>Image2<span style="color:red;">*</span></label><br>
<img src="<?php echo $subdir.$image_2;?>" alt="image2 " height="auto" width="30%">
</div>

<div class="form-group">
<label>Upload Image 2<span style="color:red;">*</span></label>
<input  type="file" name="img_2"   />
</div>



<button type="submit" name="update" class="btn btn-info">Update </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
	<script>
		document.getElementById("price").addEventListener("focusout", total_price);
		function total_price()
		{
			var qty = document.getElementById("qty").value;
			var price = document.getElementById("price").value;
			var total = document.getElementById("total");
			total.value = qty*price;
		}
		document.getElementById("qty").addEventListener("focusout", qty);
		function qty()
		{
			var qty = document.getElementById("qty").value;
			var price = document.getElementById("price").value;
			var total = document.getElementById("total");
			total.value = qty*price;
		}
		
		function update_date()
		{
			document.getElementById("e_date").style.display="block";
		}
		
		
		(function gettime() {
    var hours = new Date().getHours();
    var hours = (hours+24-2)%24; 
    var mid='am';
    if(hours==0){ //At 00 hours we need to show 12 am
    hours=12;
    }
    else if(hours>12)
    {
    hours=hours%12;
    mid='pm';
    }
    alert ('Toronto time: ' + hours + mid);
}
	</script>
	
	
</body>
</html>
<?php }  ?>
