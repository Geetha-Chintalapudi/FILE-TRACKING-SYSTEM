<?php
session_start();
//$_SESSION['ulogin'] = "mohamed@riswan.com";
error_reporting(0);
include('includes/config.php');
include('includes/functions.php');


if(strlen($_SESSION['alogin'])==0)
{   
header('location:index.php');
}
else{ 

 if(isset($_SESSION['ulogin']))
 {
  $sender_email = $_SESSION['ulogin'];
  $get_userid = "select * from users where email = '$sender_email'";
  $run_userid = mysqli_query($con, $get_userid);
  $row_userid = mysqli_fetch_array($run_userid);
  $sender_id = $row_userid['id'];
 } 

if(isset($_POST['send_file']))
{
  $target_file = "files/";
  $receiver=addslashes($_POST['user_name']);
  $receiver = explode("-", $receiver);
  $receiver_id = $receiver[0];
  $file_tosend = $_FILES["file_tosend"]["name"];  
  $file_tosend_tmp = $_FILES["file_tosend"]["tmp_name"];
  if(move_uploaded_file($file_tosend_tmp, $target_file.$file_tosend))
  {
    $sql = "INSERT INTO send_files (sender, receiver, file) VALUES ('$sender_id','$receiver_id', '$file_tosend')";
    if (mysqli_query($con, $sql)) 
    {
      
     $_SESSION['success'] = "File sent successfully";
     
      header("Refresh:1; url=".$site_url."send_file.php");
        
    }   
    else {
      
     $_SESSION['error']="Category Not Created  ";
      }
  }
}
			
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
   <title>File Sharing | Send File</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Send File</h4>
                
                            </div>

</div>
<div class="row">
<?php if($_SESSION['error']!="")
    {?>	
<div class="col-md-6">
<div class="alert alert-danger" >
 <strong>Error :</strong> 
 <?php echo htmlentities($_SESSION['error']);?>
<?php echo htmlentities($_SESSION['error']="");?>
</div>
</div>
<?php } ?>
<?php if($_SESSION['success']!="")
{?>
<div class="col-md-6">
<div class="alert alert-success" >
 <strong>Success :</strong> 
 <?php echo htmlentities($_SESSION['success']);?>
<?php echo htmlentities($_SESSION['success']="");?>
</div>
</div>
<?php } ?>
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Send File
</div>
<div class="panel-body">
<form action="" role="form" method="post" enctype="multipart/form-data">

<div class="form-group">
	<label> Select User<span style="color:red;">*</span></label>
	<input class="form-control" name="user_name" list="userlist" required />
  <datalist id="userlist">
  <?php 
$catsql = "SELECT * from users where id != '$sender_id'";
  $run_catsql =   mysqli_query($con,$catsql);
  while($row = mysqli_fetch_array($run_catsql))
  {        
         ?>                                      
        <option value="<?php  echo $row['id']."-".$row['user_name']; ?>">
        <?php }?>
      </datalist>
</div>
<div class="form-group">
  <label>Select File<span style="color:red;">*</span></label>
  <input class="form-control" type="file" name="file_tosend" required="" />
</div>  
 <?php } ?>
<button type="submit" name="send_file" class="btn btn-info">Send File</button>

</form>
 </div>
 </div>
 </div>
  </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="<?php echo $site_url; ?>assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo $site_url; ?>assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="<?php echo $site_url; ?>assets/js/custom.js"></script>
	
</body>
</html>
<?php  ?>
