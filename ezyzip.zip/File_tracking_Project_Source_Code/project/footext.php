<?php
session_start();
error_reporting(0);
include('includes/config.php');


if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 


$sql = "SELECT * from footer";
$run_sql = 	mysqli_query($con,$sql);
$row = mysqli_fetch_array($run_sql);
$description = stripslashes($row['description']);



 





if(isset($_POST['update']))
{

 $description =addslashes( $_POST['description']);



  $update_sql="update footer set description='$description'";
  if (mysqli_query($con, $update_sql)) {
		        //  echo "Updated: ";
			 header('location:footext.php');
				} 
				else {
				echo "Error: " . $sql . "<br>" . mysqli_error($con);
				}
         //print_r($errors);
  


}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>SmileyVart | Update Footer Block</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Update  Settings</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Footer Block Info
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">




<div class="form-group">
	<label> Description<span style="color:red;">*</span></label>
	<textarea class="form-control" type="text" name="description"  maxlength="405" autocomplete="off"  required ><?php $var=strlen($description); echo $description; ?> </textarea>
</div>

 <?php } ?>
<button type="submit" name="update" class="btn btn-info">Update </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
	
</body>
</html>
<?php  ?>
