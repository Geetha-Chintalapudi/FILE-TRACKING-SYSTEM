<?php
session_start();
error_reporting(0);
include('includes/config.php');
include('includes/functions.php');

if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

if(isset($_GET['upid']))
{
	$id1=$_GET['upid'];
} 
$fet_sql="SELECT * FROM subcategories WHERE is_subcat_home='Yes'";
$run_fet_sql=mysqli_query($con, $fet_sql);
 

$sql = "SELECT * from subcategories where id='$id1'";
$cnt=1;
$run_sql = 	mysqli_query($con,$sql);

$row = mysqli_fetch_array($run_sql);

$title = stripslashes($row['sub_cat_name']);
$cat_id = stripslashes($row['cat_id']);
$subdisplay = stripslashes($row['is_subcat_home']);



if(isset($_POST['update']))
{
$title =addslashes( $_POST['title']);
$cat_id =addslashes( $_POST['categories']);
$is_home = (isset($_POST['display'])) ? "Yes" :"No";

$update_sql="update subcategories set sub_cat_name='$title',cat_id='$cat_id',is_subcat_home='$is_home' where id='$id1'" ;
if (mysqli_query($con, $update_sql)) {
	
	header('location:manage_sub_cat.php');
				} 
	else {
	echo "Error: " . $sql . "<br>" . mysqli_error($con);
	}
		  


			 
		


}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Smileywart | Update Subcategory</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="<?php echo $site_url; ?>assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    
        <div class="col-lg-8 col-md-8 col-sm-8 content-wrapper">
         <div class="">
        <div class="row ">
            <div class="col-md-12">
                <h4 class="header-line">Update Subcategory Settings</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 col-md-offset-3" style="margin-left:20px;">
<div class="panel panel-info">
<div class="panel-heading">
Update Subcategory 
</div>
<div class="panel-body">
<form role="form" method="post" enctype="multipart/form-data">


<div class="form-group">
	<label>Name<span style="color:red;">*</span></label>
	<input class="form-control" type="text" name="title" autocomplete="off"  value="<?php echo $title; ?>" required />
</div>




<div class="form-group">	
<label>categories<span style="color:red;">*</span></label><br>
<select name="categories" required>
<?php 
$catsql = "SELECT * from categories ";
$run_catsql = 	mysqli_query($con,$catsql);
while($row = mysqli_fetch_array($run_catsql))
{        
?>                                      
  <option  value="<?php echo $row['id']; ?>" <?php if($cat_id==$row['id']) { echo "Selected"; } ?>><?php echo $row['cat_name']; ?> </option>
<?php } ?>
</select>
	</div>
	
	

<div class="form-group">
  
	<?php  if(mysqli_num_rows($run_fet_sql) > 2 && $subdisplay=="No" ) {?>
	
	<label> Only 3 categories of products are Displayed in Homepage.Not More<span style="color:red;">*</span></label><br>
    <input type="checkbox" name="display" value="No" hidden > <br>
	

	<?php } else if($subdisplay=="Yes") {?>
	  
	  <input type="checkbox" name="display" value="Yes" checked> Display In Page  <br>

	  <?php } else if(mysqli_num_rows($run_fet_sql) <= 2 && $subdisplay=="No" ) { ?>
	  <input type="checkbox" name="display" value="No" > Display In HomePage condition <br>
	  <?php }  ?>
	  
	
</div>

	
	
		
	
	
	

</div>




<button type="submit" name="update" class="btn btn-info">Update </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
	<script>
		
	</script>
</body>
</html>
<?php } ?>
