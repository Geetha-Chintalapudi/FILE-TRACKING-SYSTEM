<!-- Sidebar Holder -->
    <div class="col-lg-3 col-md-3 col-sm-4 wrapper side_bar">
        <nav id="sidebar">
		
            <div class="profile-bg" ></div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="index.php">
                        <i class="fas fa-th-large"></i>
                        Welcome
                    </a>
                </li>
				<li>
                    <a href="#sitesettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Site Setting
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="sitesettingSubmenu1">
                        
                        <li>
                            <a href="edit_site.php">View & Edit Site Setting</a>
                        </li>
                       
                    </ul>
                </li>
				<li>
                    <a href="#LoginsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Login Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="LoginsettingSubmenu1">
                        
                        <li>
                            <a href="edit_login.php">View & Edit Login Page Settings</a>
                        </li>
                       
                    </ul>
                </li>
				<li>
                    <a href="#MyAcountsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        My Acount Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="MyAcountsettingSubmenu1">
                        
                        <li>
                            <a href="edit_my_account.php">View & Edit My Acount Page Settings</a>
                        </li>
                       
                    </ul>
                </li>
				<li>
                    <a href="#ContactsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Contact Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="ContactsettingSubmenu1">
                        <li>
                            <a href="edit_contact.php">View & Edit Contact Page Settings</a>
                        </li>
                    </ul>
                </li>
				<li>
                    <a href="#CaontactsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        About Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="CaontactsettingSubmenu1">
                        <li>
                            <a href="edit_about.php">View & Edit About Page Settings</a>
                        </li>
                    </ul>
                </li>
				<li>
                    <a href="#CaontatsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Terms & Conditions Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="CaontatsettingSubmenu1">
                        <li>
                            <a href="edit_terms.php">View & Edit Terms & Conditions Page Settings</a>
                        </li>
                    </ul>
                </li>
				<li>
                    <a href="#paymentsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        Payment Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="paymentsettingSubmenu1">
                        <li>
                            <a href="edit_payment.php">View & Edit Payment Page Settings</a>
                        </li>
                    </ul>
                </li>
				<li>
                    <a href="#liistsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Registration Pages Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="liistsettingSubmenu1">
                        
                        <li>
                            <a href="edit_reg_pages.php">View & Edit Registration Pages Settings</a>
                        </li>
                       
                    </ul>
                </li>
				<li>
                    <a href="#listsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        List Pages Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="listsettingSubmenu1">
                        
                        <li>
                            <a href="edit_list_pages.php">View & Edit List Pages Settings</a>
                        </li>
                       
                    </ul>
                </li>
				<li>
                    <a href="#ontactsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Thankyou Page Settings
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="ontactsettingSubmenu1">
                        <li>
                            <a href="edit_gnotice.php">View & Edit Groom Thankyou Page Settings</a>
                        </li>
						<li>
                            <a href="edit_bnotice.php">View & Edit Bride Thankyou Page Settings</a>
                        </li>
                    </ul>
                </li>
				<li>
                    <a href="#sliderSubmenu1" data-toggle="collapse" aria-expanded="false">
                       
                        Users
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="sliderSubmenu1">
                        <li>
                            <a href="view_free_members.php">Free Members</a>
                        </li>
                        <li>
                            <a href="view_paid_members.php">Premium Members</a>
                        </li>
                       
                    </ul>
                </li>
				<li>
                    <a href="#otactsettingSubmenu1" data-toggle="collapse" aria-expanded="false">
                        
                        Change Admin Username and Password
                        <i class="fas fa-angle-down fa-pull-right"></i>
                    </a>
                    <ul class="collapse list-unstyled" id="otactsettingSubmenu1">
                        <li>
                            <a href="edit_adminpass.php">Change Username and Password</a>
                        </li>
                    </ul>
                </li>
				
                <li>
                    <a href="logout.php">
                       
                        Logout
                        <!--span class="badge badge-secondary float-md-right bg-danger">5 New</span-->
                    </a>
                </li>
               
                    
            </ul>
        </nav>
		</div>
 <!-- Sidebar Holder ends--> 	