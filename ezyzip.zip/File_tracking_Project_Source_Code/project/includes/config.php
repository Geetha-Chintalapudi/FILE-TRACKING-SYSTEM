<?php 
// DB credentials.
$dbusername = "root";
$dbpassword = "";
$dbname = "jsldesfl_file_share";

$con = mysqli_connect("localhost",$dbusername,$dbpassword,$dbname);



?>