   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; <a href="http://aknu.edu.in" target="_blank"  > Designed & Developed by : Geetha Chintalapudi</a> 
                </div>

            </div>
        </div>
    </section>