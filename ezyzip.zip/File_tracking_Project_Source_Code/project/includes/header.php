<?php
    if(isset($_SESSION['alogin']))
     {
      $login_user_email = $_SESSION['alogin'];
      $get_userid = "select * from users where email = '$login_user_email'";
      $run_userid = mysqli_query($con, $get_userid);
      $row_userid = mysqli_fetch_array($run_userid);
    $login_user_id = $row_userid['id'];
    $noti = $row_userid['expire_noti'];

     }
    $get_new_files = "select * from send_files where receiver = '$login_user_id' && noti = '0'";
    $run_new_files = mysqli_query($con, $get_new_files);
    $num_rows = mysqli_num_rows($run_new_files);
?>
<!-- Sidebar Holder -->
	<div class="col-lg-12 col-md-12 col-sm-12">
		<img src="" class="img-responsive">
	</div>
    <div class="col-lg-3 col-md-3 col-sm-3 wrapper side_bar" <?php if($_SESSION['alogin']) { echo "style='background-color: #1a0082;'"; } ?>>
        <nav id="sidebar">
            <div class="profile-bg" ></div>
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                        DASHBOARD
                    </a>
                </li>	
				
                <?php if (isset($_SESSION['alogin'])) { ?>				
				<li>
					<a href="users.php">Users <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
				</li>

                 <li>
                    <a href="file_transfer.php">File Transfered <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>

                <li>
                    <a href="change-password.php">Change Password <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>
                 <li>
                    <a href="registration.php">Register New User <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>
				
				<!-- <li>
					<a href="site_settings.php">Site Settings <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
				</li> -->
            <?php } elseif (isset($_SESSION['ulogin'])) { ?>

                <li>
                    <a href="send_file.php">Send File <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>

                <li>
                    <a href="receive_file.php">Recieved File<span style="margin-left: 10px; padding: 0px 4px; background-color: #fff; color: #000; border-radius: 50%; "><?php echo $num_rows; ?></span> <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>

                <li>
                    <a href="files_sent.php">Sent Files <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>
                <li>
                    <a href="noti.php">Notifications <?php if( $noti != "") { ?><i class="fa fa-exclamation-circle" aria-hidden="true"></i><?php } ?></a>
                </li>
                <li>
                    <a href="change-password.php">Change Password <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
                </li>
            <?php } ?>
                <li>
                    <a href="logout.php">
                        Logout <i class="fa fa-sign-out" aria-hidden="true"></i>
                        <!--span class="badge badge-secondary float-md-right bg-danger">5 New</span-->
                    </a>
                </li>
            </ul>
        </nav>
		</div>
 <!-- Sidebar Holder ends--> 	