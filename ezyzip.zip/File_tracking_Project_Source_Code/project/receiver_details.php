<?php
include('includes/config.php');
	if (isset($_POST['u_id'])) {
    $user_id = $_POST['u_id'];
    $get_receiver_details = "select * from users where id = '$user_id'";
    $run_receiver_details = mysqli_query($con, $get_receiver_details);
    $row_receiver_details = mysqli_fetch_array($run_receiver_details);
    // echo $row_receiver_details['collegename'];
  ?>
  	<input type="hidden" name="user_name" value="<?php echo $user_id; ?>" >
    <div class="form-group">
      <label>College Name<span style="color:red;">*</span></label>
      <input class="form-control" type="text" name="clg_name" value="<?php echo $row_receiver_details['collegename'] ?>" readonly="" />
    </div>
    <div class="form-group">
      <label>Department Name<span style="color:red;">*</span></label>
      <input class="form-control" type="text" name="dept_name" value="<?php echo $row_receiver_details['dept_name'] ?>" readonly="" />
    </div>
  <?php
  }
?>