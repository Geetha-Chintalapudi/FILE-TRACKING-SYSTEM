<?php
session_start();
include('includes/config.php');
//include('includes/functions.php');
if(isset($_POST['login']))
{
$username=$_POST['username'];
$password=md5($_POST['password']);
$sql ="SELECT * FROM admin WHERE UserName='$username' and Password='$password'";
 $sql1 ="SELECT * FROM users WHERE email='$username' and u_password='$password'";
if(mysqli_num_rows($run_query=mysqli_query($con,$sql))>0)
{
$_SESSION['alogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
} 
 else if(mysqli_num_rows($run_query1=mysqli_query($con,$sql1))>0)
 {
    $_SESSION['ulogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
 }

 else{
    echo "<script>alert('Invalid Details');</script>";
}
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>File Tracking System, Adikavi Nannya University</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="https://fonts.googleapis.com/css?family=Advent+Pro&display=swap" rel="stylesheet">
</head>
<body style="/*background:url('assets/img/bg.jpg') no-repeat;background-size:cover;*/">
    <!------MENU SECTION START-->
<?php //include('includes/header.php');?>
<!-- MENU SECTION END-->
<h4 style="font-size: 25px;
    font-weight: 500;
    font-style: oblique;
    text-align: center;">File Tracking System, Adikavi Nannya University</h4>
<div class="" style="background:url(assets/img/login.jpg);background-size:cover;padding-bottom:4.7%;background-position:center right;">
<div class="container">
<div class="row pad-botm" style="padding-bottom:10%;">
<div class="col-md-12">
<!--h4 class="header-line">ADMIN LOGIN FORM</h4-->
</div>
</div>
<!--LOGIN PANEL START-->           
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-12" >
<div class="panel panel-info">
<div class="panel-heading" style="background:#444F47;font-weight:bold;font-size:30px;font-family: 'Advent Pro', sans-serif;">
 LOGIN FORM
</div>
<div class="panel-body" style="background:#DA4856;">
<form role="form" method="post">
<div class="form-group">
<label style="font-family: 'Advent Pro', sans-serif; color:#fff;">Enter Username</label>
<input style="width:70%" class="form-control" type="email" name="username" required />
</div>
<div class="form-group">
<label style="font-family: 'Advent Pro', sans-serif; color:#fff;">Password</label>
<input style="width:70%" class="form-control" type="password" name="password" required />
</div>
 <button type="submit" style="background:#444F47;" name="login" class="btn btn-info">LOGIN </button>
 
</form>
 </div>
</div>
</div>
<!---LOGIN PABNEL END-->            
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
 <?php //include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
